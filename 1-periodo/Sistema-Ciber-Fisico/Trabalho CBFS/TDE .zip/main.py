import machine
import time

led_verde_pin = machine.Pin(4, machine.Pin.OUT)  # Pino GPIO para o LED verde externo
led_vermelho_pin = machine.Pin(2, machine.Pin.OUT)  # Pino GPIO para o LED vermelho externo

pir_pin = machine.Pin(5, machine.Pin.IN)  # Pino GPIO para o sensor PIR

trig_pin = machine.Pin(12, machine.Pin.OUT)  # Pino GPIO para o pino de trigger do HC-SR04
echo_pin = machine.Pin(13, machine.Pin.IN)  # Pino GPIO para o pino de echo do HC-SR04

def medir_distancia():
    trig_pin.on()
    time.sleep_us(10)
    trig_pin.off()

    while echo_pin.value() == 0:
        pass
    pulse_start = time.ticks_us()

    while echo_pin.value() == 1:
        pass
    pulse_end = time.ticks_us()

    pulse_duration = pulse_end - pulse_start
    distance = pulse_duration * 0.0343 / 2

    return distance

while True:
    # Verifica se a vaga está ocupada pelo sensor PIR
    if pir_pin.value() == 1:
        led_verde_pin.on()  # Acende o LED verde externo
        led_vermelho_pin.off()  # Apaga o LED vermelho externo
        print("Vaga ocupada")
    else:
        led_verde_pin.off()  # Apaga o LED verde externo
        led_vermelho_pin.on()  # Acende o LED vermelho externo
        print("Vaga desocupada")

    # Mede a distância usando o HC-SR04
    distancia = medir_distancia()
    print("Distância: {} cm".format(distancia))

    # Aguarda um intervalo de tempo antes de repetir a leitura
    time.sleep(1)
